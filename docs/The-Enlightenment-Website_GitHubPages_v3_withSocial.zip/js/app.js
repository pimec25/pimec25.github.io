// Mobile nav toggle
const toggle = document.querySelector('.nav-toggle');
const nav = document.getElementById('siteNav');
if (toggle && nav) {
  toggle.addEventListener('click', () => {
    const open = nav.classList.toggle('open');
    toggle.setAttribute('aria-expanded', open ? 'true' : 'false');
  });
}
const y = document.getElementById('year'); if (y) y.textContent = new Date().getFullYear();


// ---- Spotify Artist Follow Config ----
// Replace with your artist ID (letters/numbers). Example: '1Xyo4u8uXC1ZmMpatF05PJ'
window.SPOTIFY_ARTIST_ID = window.SPOTIFY_ARTIST_ID || "SPOTIFY_ARTIST_ID_HERE";

(function(){
  const id = window.SPOTIFY_ARTIST_ID;
  const follow = document.getElementById('spotify-follow');
  const link = document.getElementById('spotify-artist-link');
  if (!follow && !link) return;
  if (id && id !== 'SPOTIFY_ARTIST_ID_HERE'){
    if (follow){
      follow.src = `https://open.spotify.com/follow/1/?uri=spotify:artist:${id}&size=detail&theme=dark`;
      follow.removeAttribute('hidden');
    }
    if (link){
      link.href = `https://open.spotify.com/artist/${id}`;
      link.removeAttribute('hidden');
    }
  } else {
    if (follow) follow.setAttribute('hidden','hidden');
    if (link) link.setAttribute('hidden','hidden');
  }
})();

(function(){
  const id = window.SPOTIFY_ARTIST_ID;
  const homeFollow = document.getElementById('spotify-artist-link-home');
  if (homeFollow){
    if (id && id !== 'SPOTIFY_ARTIST_ID_HERE'){
      homeFollow.href = `https://open.spotify.com/artist/${id}`;
      homeFollow.removeAttribute('hidden');
      homeFollow.textContent = 'Follow on Spotify';
    } else {
      homeFollow.setAttribute('hidden','hidden');
    }
  }
})();


/* ---- Spotify Artist Follow Config ----
   Replace SPOTIFY_ARTIST_ID_HERE with your artist ID (letters/numbers). */
window.SPOTIFY_ARTIST_ID = window.SPOTIFY_ARTIST_ID || "SPOTIFY_ARTIST_ID_HERE";

(function(){
  const id = window.SPOTIFY_ARTIST_ID;
  const follow = document.getElementById('spotify-follow');
  const link = document.getElementById('spotify-artist-link');
  if (follow){
    if (id && id !== 'SPOTIFY_ARTIST_ID_HERE'){
      follow.src = `https://open.spotify.com/follow/1/?uri=spotify:artist:${id}&size=detail&theme=dark`;
      follow.removeAttribute('hidden');
    } else {
      follow.setAttribute('hidden','hidden');
    }
  }
  if (link){
    if (id && id !== 'SPOTIFY_ARTIST_ID_HERE'){
      link.href = `https://open.spotify.com/artist/${id}`;
      link.removeAttribute('hidden');
    } else {
      link.setAttribute('hidden','hidden');
    }
  }
})();

(function(){
  const id = window.SPOTIFY_ARTIST_ID;
  const homeFollow = document.getElementById('spotify-artist-link-home');
  if (homeFollow){
    if (id && id !== 'SPOTIFY_ARTIST_ID_HERE'){
      homeFollow.href = `https://open.spotify.com/artist/${id}`;
      homeFollow.removeAttribute('hidden');
      homeFollow.textContent = 'Follow on Spotify';
    } else {
      homeFollow.setAttribute('hidden','hidden');
    }
  }
})();
