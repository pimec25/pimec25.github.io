# The Enlightenment — Official Artist Website

This repository hosts the public website for **The Enlightenment**, deployed via **GitHub Pages** and branded for **pimecineng.com**.

## Files
- `index.html` — Homepage
- `about.html` — Who We Are page
- `CNAME` — Custom domain mapping (pimecineng.com)
- `.nojekyll` — Disable Jekyll for static assets
- `robots.txt` & `sitemap.xml` — SEO basics
- `assets/` — Images, icons, PDFs, MP3s

## Deploy
1. Push to a repo (e.g., `the-enlightenment-site`) on the `main` branch.
2. In GitHub → Settings → Pages → Source: **Deploy from a branch** → `main` → `/ (root)`.
3. For custom domain: Add **pimecineng.com** in Pages settings and include the `CNAME` file.

## Notes
- If you deploy under `username.github.io/repo`, uncomment the `<base>` tag in each HTML file.
- Replace Formspree `{your-id}` with your form ID to collect fan emails.
